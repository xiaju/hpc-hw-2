** to compile:
g++ philo.cpp -std=c++11 -lpthread

** to run:
./a.out <Number of Philsophers> <arg>

arg = 0: don't run with any special cases
arg = 1: run giving priority to the 0th index philosopher
arg = 2: run with a fork in the middle of the table
